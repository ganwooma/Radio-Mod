package dev.ganwooma.radiomod;

import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public class FirstAidKitHealHandler extends class_1792 {

    public FirstAidKitHealHandler(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1271<class_1799> method_7836(
            class_1937 world,
            class_1657 user,
            class_1268 hand
    ) {

        class_1799 stack =
                user.method_5998(hand);

        if (!world.field_9236) {

            // 재생 3 (0=1, 1=2, 2=3)
            user.method_6092(
                    new class_1293(
                            class_1294.field_5924,
                            20 * 3,
                            2
                    )
            );

            // 소리
            world.method_8396(
                    null,
                    user.method_24515(),
                    class_3417.field_20615,
                    class_3419.field_15248,
                    1.0F,
                    1.0F
            );

            // 크리에이티브 아니면 1개 소비
            if (!user.method_31549().field_7477) {
                stack.method_7934(1);
            }
        }

        return class_1271.method_29237(
                stack,
                world.method_8608()
        );
    }
}