package dev.ganwooma.radiomod;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import dev.ganwooma.radiomod.config.ConfigManager;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1810;
import net.minecraft.class_1829;
import net.minecraft.class_2170;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import net.minecraft.item.*;

public class Radiomod implements ModInitializer {

    public static final class_1792 BROKEN_RADIO = new class_1792(new FabricItemSettings());
    public static final class_1792 RADIO = new Ending(new FabricItemSettings());
    public static final class_1792 DEAD_RADIO = new class_1792(new FabricItemSettings());
    public static final class_1792 COPPER_WIRE = new class_1792(new FabricItemSettings());
    public static final class_1792 COPPER_THREAD = new class_1792(new FabricItemSettings());
    public static final class_1792 ANTENNA = new class_1792(new FabricItemSettings());
    public static final class_1792 BATTERY = new class_1792(new FabricItemSettings());
    public static final class_1792 FIRST_AID_KIT = new class_1792(new FabricItemSettings());

    public static final class_1792 MINER_PICKAXE = class_2378.method_10230(
            class_7923.field_41178,
            new class_2960("radiomod", "miner_pickaxe"),
            new class_1810(
                    new MinerPickaxeToolMaterial(),
                    1,
                    -2.8F,
                    new FabricItemSettings()
            )
    );

    public static final class_1792 LONG_SWORD = class_2378.method_10230(
            class_7923.field_41178,
            new class_2960("radiomod", "long_sword"),
            new class_1829(
                    new LongSwordToolMaterial(),
                    1,
                    -3.6F,
                    new FabricItemSettings()
            )
    );

    public static final class_1792 BAT = class_2378.method_10230(
            class_7923.field_41178,
            new class_2960("radiomod", "bat"),
            new class_1829(
                    new BatToolMaterial(),
                    1,
                    -3.6F,
                    new FabricItemSettings()
            )
    );

    public static final class_1792 FIELD_SHOVEL = class_2378.method_10230(
            class_7923.field_41178,
            new class_2960("radiomod", "field_shovel"),
            new class_1829(
                    new FieldShovelToolMaterial(),
                    1,
                    -2.8F,
                    new FabricItemSettings()
            )
    );

    public static final class_1792 GAUZE = class_2378.method_10230(
            class_7923.field_41178,
            new class_2960("radiomod", "gauze"),
            new class_1829(
                    new FieldShovelToolMaterial(),
                    1,
                    -2.8F,
                    new FabricItemSettings()
            )
    );

    public static final class_1792 HAMMER = class_2378.method_10230(
            class_7923.field_41178,
            new class_2960("radiomod", "hammer"),
            new class_1829(
                    new HammerToolMaterial(),
                    2,
                    -3F,
                    new FabricItemSettings()
            )
    );

    public static final class_2248 GOLD_BARREL = class_2378.method_10230(
            class_7923.field_41175,
            new class_2960("radiomod", "gold_barrel"),
            new GoldBarrelBlock(
                    class_4970.class_2251.method_9630(class_2246.field_16328)
            )
    );

    public static final class_1792 GOLD_BARREL_ITEM = class_2378.method_10230(
            class_7923.field_41178,
            new class_2960("radiomod", "gold_barrel"),
            new class_1747(GOLD_BARREL, new FabricItemSettings())
    );

    public static final class_2248 IRON_BARREL = class_2378.method_10230(
            class_7923.field_41175,
            new class_2960("radiomod", "iron_barrel"),
            new IronBarrelBlock(
                    class_4970.class_2251.method_9630(class_2246.field_16328)
            )
    );

    public static final class_1792 IRON_BARREL_ITEM = class_2378.method_10230(
            class_7923.field_41178,
            new class_2960("radiomod", "iron_barrel"),
            new class_1747(IRON_BARREL, new FabricItemSettings())
    );


    public static final class_1761 RADIO_GROUP = class_2378.method_10230(class_7923.field_44687,
            class_2960.method_43902("radio", "radio_group"), FabricItemGroup.builder().method_47320(() ->
                    new class_1799(BROKEN_RADIO)).method_47321(class_2561.method_43471("itemGroup.radiomod.radiomod")).method_47324());
    public static final class_5321<class_1761> RADIO_GROUP_KEY =
            class_5321.method_29179(class_7923.field_44687.method_30517(), class_2960.method_43902("radio", "radio_group"));

    private static int scanTimer = 0;

    @Override
    public void onInitialize() {

        ConfigManager.load();
        GauzeHealHandler.register();

        class_2378.method_10230(class_7923.field_41178, class_2960.method_43902("radiomod", "broken_radio"), BROKEN_RADIO);
        ItemGroupEvents.modifyEntriesEvent(RADIO_GROUP_KEY).register(entries -> {entries.method_45421(BROKEN_RADIO);});
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40200).register(entries -> {entries.method_45421(BROKEN_RADIO);});

        class_2378.method_10230(class_7923.field_41178, class_2960.method_43902("radiomod", "radio"), RADIO);
        ItemGroupEvents.modifyEntriesEvent(RADIO_GROUP_KEY).register(entries -> {entries.method_45421(RADIO);});
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40200).register(entries -> {entries.method_45421(RADIO);});

        class_2378.method_10230(class_7923.field_41178, class_2960.method_43902("radiomod", "dead_radio"), DEAD_RADIO);
        ItemGroupEvents.modifyEntriesEvent(RADIO_GROUP_KEY).register(entries -> {entries.method_45421(DEAD_RADIO);});
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40200).register(entries -> {entries.method_45421(DEAD_RADIO);});

        class_2378.method_10230(class_7923.field_41178, class_2960.method_43902("radiomod", "copper_thread"), COPPER_THREAD);
        ItemGroupEvents.modifyEntriesEvent(RADIO_GROUP_KEY).register(entries -> {entries.method_45421(COPPER_THREAD);});
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40200).register(entries -> {entries.method_45421(COPPER_THREAD);});

        class_2378.method_10230(class_7923.field_41178, class_2960.method_43902("radiomod", "copper_wire"), COPPER_WIRE);
        ItemGroupEvents.modifyEntriesEvent(RADIO_GROUP_KEY).register(entries -> {entries.method_45421(COPPER_WIRE);});
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40200).register(entries -> {entries.method_45421(COPPER_WIRE);});

        class_2378.method_10230(class_7923.field_41178, class_2960.method_43902("radiomod", "antenna"), ANTENNA);
        ItemGroupEvents.modifyEntriesEvent(RADIO_GROUP_KEY).register(entries -> {entries.method_45421(ANTENNA);});
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40200).register(entries -> {entries.method_45421(ANTENNA);});

        class_2378.method_10230(class_7923.field_41178, class_2960.method_43902("radiomod", "battery"), BATTERY);
        ItemGroupEvents.modifyEntriesEvent(RADIO_GROUP_KEY).register(entries -> {entries.method_45421(BATTERY);});
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40200).register(entries -> {entries.method_45421(BATTERY);});

        class_2378.method_10230(class_7923.field_41178, class_2960.method_43902("radiomod", "first_aid_kit"), FIRST_AID_KIT);
        ItemGroupEvents.modifyEntriesEvent(RADIO_GROUP_KEY).register(entries -> {entries.method_45421(FIRST_AID_KIT);});
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40200).register(entries -> {entries.method_45421(FIRST_AID_KIT);});

        ItemGroupEvents.modifyEntriesEvent(RADIO_GROUP_KEY).register(entries -> {entries.method_45421(MINER_PICKAXE);});
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40200).register(entries -> {entries.method_45421(MINER_PICKAXE);});

        ItemGroupEvents.modifyEntriesEvent(RADIO_GROUP_KEY).register(entries -> {entries.method_45421(LONG_SWORD);});
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40200).register(entries -> {entries.method_45421(LONG_SWORD);});

        ItemGroupEvents.modifyEntriesEvent(RADIO_GROUP_KEY).register(entries -> {entries.method_45421(BAT);});
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40200).register(entries -> {entries.method_45421(BAT);});

        ItemGroupEvents.modifyEntriesEvent(RADIO_GROUP_KEY).register(entries -> {entries.method_45421(FIELD_SHOVEL);});
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40200).register(entries -> {entries.method_45421(FIELD_SHOVEL);});

        ItemGroupEvents.modifyEntriesEvent(RADIO_GROUP_KEY).register(entries -> {entries.method_45421(GAUZE);});
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40200).register(entries -> {entries.method_45421(GAUZE);});

        ItemGroupEvents.modifyEntriesEvent(RADIO_GROUP_KEY).register(entries -> {entries.method_45421(HAMMER);});
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40200).register(entries -> {entries.method_45421(HAMMER);});

        ItemGroupEvents.modifyEntriesEvent(RADIO_GROUP_KEY).register(entries -> {entries.method_45421(GOLD_BARREL_ITEM);});
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40200).register(entries -> {entries.method_45421(GOLD_BARREL_ITEM);});

        ItemGroupEvents.modifyEntriesEvent(RADIO_GROUP_KEY).register(entries -> {entries.method_45421(IRON_BARREL_ITEM);});
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40200).register(entries -> {entries.method_45421(IRON_BARREL_ITEM);});

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {

            dispatcher.register(class_2170.method_9247("transformbarrels")
                    .requires(source -> source.method_9259(2))
                    .executes(context -> {

                        class_3222 player = context.getSource().method_44023();

                        BarrelScanner.scan(
                                player.method_51469(),
                                player.method_24515()
                        );

                        return 1;
                    }));
        });
        ServerTickEvents.END_SERVER_TICK.register(server -> {

            int maxPerTick = 2;

            for (int i = 0; i < maxPerTick; i++) {

                class_2338 pos =
                        BarrelQueueProcessor.QUEUE.poll();

                if (pos == null) {
                    return;
                }

                class_3218 world =
                        server.method_30002();

                BarrelTransformer.transform(world, pos);
                BarrelQueueProcessor.KNOWN.remove(pos);
            }
        });
        ServerTickEvents.END_SERVER_TICK.register(server -> {

            scanTimer++;

            if (scanTimer < 20) {
                return;
            }

            scanTimer = 0;

            for (class_3222 player :
                    server.method_3760().method_14571()) {

                BarrelScanner.scan(
                        player.method_51469(),
                        player.method_24515()
                );
            }
        });
    }
}
