package dev.ganwooma.radiomod;


import dev.ganwooma.radiomod.loot.LootHelper;
import java.util.Random;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_3218;

import static dev.ganwooma.radiomod.Radiomod.GOLD_BARREL;
import static dev.ganwooma.radiomod.Radiomod.IRON_BARREL;

public class BarrelTransformer {

    private static final Random RANDOM =
            new Random();

    public static void transform(
            class_3218 world,
            class_2338 pos
    ) {

        boolean gold = RANDOM.nextDouble() < 0.2;

        class_2350 facing =
                world.method_8320(pos)
                        .method_11654(class_2741.field_12481);

        class_2680 state =
                (gold ? GOLD_BARREL : IRON_BARREL)
                        .method_9564()
                        .method_11657(class_2741.field_12525, facing);

        // 조용히 교체
        world.method_8544(pos);

        world.method_8652(pos, state, 2);

        LootHelper.fillBarrel(world, pos, gold);
    }
}