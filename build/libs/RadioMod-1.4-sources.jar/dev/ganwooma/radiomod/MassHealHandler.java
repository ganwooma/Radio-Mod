package dev.ganwooma.radiomod;

import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;

public class MassHealHandler {

    public static void register() {

        AttackEntityCallback.EVENT.register((
                player,
                world,
                hand,
                entity,
                hitResult
        ) -> {

            if (world.field_9236) {
                return class_1269.field_5811;
            }

            // 플레이어만
            if (!(entity instanceof class_1657 target)) {
                return class_1269.field_5811;
            }

            class_1799 stack =
                    player.method_5998(hand);

            // MASS 확인
            if (!stack.method_31574(Radiomod.MASS)) {
                return class_1269.field_5811;
            }

            // 강한 공격만
            if (player.method_7261(0.5F)
                    < 1.0F) {

                return class_1269.field_5814;
            }

            // 공격 취소
            target.field_6008 = 0;

            // 힐
            target.method_6025(0.1F);

            return class_1269.field_5814;
        });
    }
}