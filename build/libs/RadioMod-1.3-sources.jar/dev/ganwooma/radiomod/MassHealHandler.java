package dev.ganwooma.radiomod;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.class_1657;
import net.minecraft.class_1799;

import static dev.ganwooma.radiomod.Radiomod.MASS;

public class MassHealHandler {
    public static void register() {
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {

            // 플레이어만 적용
            if (!(entity instanceof class_1657 player)) {
                return true;
            }

            // 공격자가 플레이어인지 확인
            if (!(source.method_5529() instanceof class_1657 attacker)) {
                return true;
            }

            // 공격자가 들고 있는 아이템 확인
            class_1799 stack = attacker.method_6047();

            if (stack.method_31574(MASS)) {

                // 강한 공격(쿨다운 차징 공격)인지 확인
                if (attacker.method_7261(0.5f) > 0.9f) {

                    // 힐 (0.1 하트 = 0.2 HP)
                    player.method_6025(0.2f);

                    // 데미지 취소
                    return false;
                }
            }

            return true;
        });
    }
}
