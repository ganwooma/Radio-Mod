package dev.ganwooma.radiomod;

import net.minecraft.class_1802;
import net.minecraft.class_1832;
import net.minecraft.class_1856;

public class MinerPickaxeToolMaterial implements class_1832 {
    @Override
    public int method_8025() {
        return Integer.MAX_VALUE;
    }

    @Override
    public float method_8027() {
        return 13.0F;
    }

    @Override
    public float method_8028() {
        return 6.0F;
    }

    @Override
    public int method_8024() {
        return 5;
    }

    @Override
    public int method_8026() {
        return 30;
    }

    @Override
    public class_1856 method_8023() {
        return class_1856.method_8091(class_1802.field_8477);
    }
}
