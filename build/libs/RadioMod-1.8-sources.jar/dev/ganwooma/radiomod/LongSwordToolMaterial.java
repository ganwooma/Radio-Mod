package dev.ganwooma.radiomod;

import net.minecraft.class_1832;
import net.minecraft.class_1856;

public class LongSwordToolMaterial implements class_1832 {
    @Override
    public int method_8025() {
        return 2147483647;
    }

    @Override
    public float method_8027() {
        return 6.0f;
    }

    @Override
    public float method_8028() {
        return 13.0f; // 기본 데미지
    }

    @Override
    public int method_8024() {
        return 2;
    }

    @Override
    public int method_8026() {
        return 15;
    }

    @Override
    public class_1856 method_8023() {
        return class_1856.field_9017; // 수리 재료
    }
}
