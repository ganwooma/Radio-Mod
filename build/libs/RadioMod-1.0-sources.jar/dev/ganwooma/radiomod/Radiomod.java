package dev.ganwooma.radiomod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7706;
import net.minecraft.class_7923;

public class Radiomod implements ModInitializer {

    public static final class_1792 BROKEN_RADIO = new class_1792(new FabricItemSettings());
    public static final class_1792 RADIO = new Ending(new FabricItemSettings());
    public static final class_1792 DEAD_RADIO = new class_1792(new FabricItemSettings());
    public static final class_1792 COPPER_WIRE = new class_1792(new FabricItemSettings());
    public static final class_1792 COPPER_THREAD = new class_1792(new FabricItemSettings());
    public static final class_1792 ANTENNA = new class_1792(new FabricItemSettings());
    public static final class_1792 BATTERY = new class_1792(new FabricItemSettings());
    public static final class_1761 RADIO_GROUP = class_2378.method_10230(class_7923.field_44687,
            class_2960.method_43902("radio", "radio_group"), FabricItemGroup.builder().method_47320(() ->
                    new class_1799(BROKEN_RADIO)).method_47321(class_2561.method_43471("itemGroup.radiomod.radiomod")).method_47324());
    public static final class_5321<class_1761> RADIO_GROUP_KEY =
            class_5321.method_29179(class_7923.field_44687.method_30517(), class_2960.method_43902("radio", "radio_group"));

    @Override
    public void onInitialize() {
        class_2378.method_10230(class_7923.field_41178, class_2960.method_43902("radiomod", "broken_radio"), BROKEN_RADIO);
        ItemGroupEvents.modifyEntriesEvent(RADIO_GROUP_KEY).register(entries -> {entries.method_45421(BROKEN_RADIO);});
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40200).register(entries -> {entries.method_45421(BROKEN_RADIO);});

        class_2378.method_10230(class_7923.field_41178, class_2960.method_43902("radiomod", "radio"), RADIO);
        ItemGroupEvents.modifyEntriesEvent(RADIO_GROUP_KEY).register(entries -> {entries.method_45421(RADIO);});
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40200).register(entries -> {entries.method_45421(RADIO);});

        class_2378.method_10230(class_7923.field_41178, class_2960.method_43902("radiomod", "dead_radio"), DEAD_RADIO);
        ItemGroupEvents.modifyEntriesEvent(RADIO_GROUP_KEY).register(entries -> {entries.method_45421(DEAD_RADIO);});
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40200).register(entries -> {entries.method_45421(DEAD_RADIO);});

        class_2378.method_10230(class_7923.field_41178, class_2960.method_43902("radiomod", "copper_thread"), COPPER_THREAD);
        ItemGroupEvents.modifyEntriesEvent(RADIO_GROUP_KEY).register(entries -> {entries.method_45421(COPPER_THREAD);});
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40200).register(entries -> {entries.method_45421(COPPER_THREAD);});

        class_2378.method_10230(class_7923.field_41178, class_2960.method_43902("radiomod", "copper_wire"), COPPER_WIRE);
        ItemGroupEvents.modifyEntriesEvent(RADIO_GROUP_KEY).register(entries -> {entries.method_45421(COPPER_WIRE);});
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40200).register(entries -> {entries.method_45421(COPPER_WIRE);});

        class_2378.method_10230(class_7923.field_41178, class_2960.method_43902("radiomod", "antenna"), ANTENNA);
        ItemGroupEvents.modifyEntriesEvent(RADIO_GROUP_KEY).register(entries -> {entries.method_45421(ANTENNA);});
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40200).register(entries -> {entries.method_45421(ANTENNA);});

        class_2378.method_10230(class_7923.field_41178, class_2960.method_43902("radiomod", "battery"), BATTERY);
        ItemGroupEvents.modifyEntriesEvent(RADIO_GROUP_KEY).register(entries -> {entries.method_45421(BATTERY);});
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40200).register(entries -> {entries.method_45421(BATTERY);});
    }

}
