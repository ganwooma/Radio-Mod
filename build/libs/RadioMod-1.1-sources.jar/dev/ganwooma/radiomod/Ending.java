package dev.ganwooma.radiomod;

import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2668;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.server.MinecraftServer;

import static dev.ganwooma.radiomod.Radiomod.DEAD_RADIO;

public class Ending extends class_1792 {
    public Ending(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        if (!world.field_9236) {
            MinecraftServer server = world.method_8503();
            class_1799 newStack = new class_1799(DEAD_RADIO);
            user.method_6122(hand, newStack);
            if (server != null) {
                for (class_3222 player : server.method_3760().method_14571()) {
                    world.method_43128(
                            null,
                            user.method_23317(), user.method_23318(), user.method_23321(),
                            class_3417.field_14931,
                            class_3419.field_15248,
                            1.0F,
                            1.0F
                    );
                    player.field_13987.method_14364(
                            new class_2668(
                                    class_2668.field_25649,
                                    1.0f
                            )
                    );
                }
            }
        }
        return class_1271.method_22427(user.method_5998(hand));
    }
}
