package dev.ganwooma.radiomod;

import net.minecraft.class_3708;
import net.minecraft.class_4970;

public class IronBarrelBlock extends class_3708 {
    public IronBarrelBlock(class_4970.class_2251 settings) {
        super(settings);
    }
}
