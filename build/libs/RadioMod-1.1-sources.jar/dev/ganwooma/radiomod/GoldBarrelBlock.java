package dev.ganwooma.radiomod;

import net.minecraft.class_3708;

public class GoldBarrelBlock extends class_3708 {
    public GoldBarrelBlock(class_2251 settings) {
        super(settings);
    }
}
