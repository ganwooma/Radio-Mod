package dev.ganwooma.radiomod;

import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_3218;

public class BarrelScanner {
    public static void scan(
            class_3218 world,
            class_2338 center
    ) {

        for (class_2338 pos : class_2338.method_10097(
                center.method_10069(-10, -10, -10),
                center.method_10069(10, 10, 10)
        )) {

            if (world.method_8320(pos)
                    .method_27852(class_2246.field_10034)) {

                class_2338 immutable =
                        pos.method_10062();

                if (!BarrelQueueProcessor.KNOWN.contains(immutable)) {

                    BarrelQueueProcessor.KNOWN.add(immutable);

                    BarrelQueueProcessor.QUEUE.add(immutable);
                }
            }
        }
    }
}
