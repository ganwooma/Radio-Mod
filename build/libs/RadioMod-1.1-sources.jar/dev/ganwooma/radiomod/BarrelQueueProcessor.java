package dev.ganwooma.radiomod;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Set;
import net.minecraft.class_2338;

public class BarrelQueueProcessor {
    public static final Queue<class_2338> QUEUE =
            new LinkedList<>();

    public static final Set<class_2338> KNOWN =
            new HashSet<>();
}
