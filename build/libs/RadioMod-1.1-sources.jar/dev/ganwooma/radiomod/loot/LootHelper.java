package dev.ganwooma.radiomod.loot;

import dev.ganwooma.radiomod.config.BarrelLootConfig;
import dev.ganwooma.radiomod.config.ConfigManager;
import dev.ganwooma.radiomod.config.LootEntry;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3719;
import net.minecraft.class_7923;

public class LootHelper {

    private static final Random RANDOM =
            new Random();

    public static void fillBarrel(
            class_3218 world,
            class_2338 pos,
            boolean gold
    ) {

        class_2586 be =
                world.method_8321(pos);

        if (!(be instanceof class_3719 barrel)) {
            return;
        }

        BarrelLootConfig config =
                gold
                        ? ConfigManager.GOLD
                        : ConfigManager.IRON;

        // rolls 만큼 아이템 생성
        for (int i = 0; i < config.rolls; i++) {

            LootEntry entry =
                    randomEntry(config.items);

            if (entry == null) {
                continue;
            }

            class_1792 item =
                    class_7923.field_41178.method_10223(
                            new class_2960(entry.item)
                    );

            // AIR 방지
            if (item == null) {
                continue;
            }

            int count =
                    RANDOM.nextInt(
                            entry.max - entry.min + 1
                    ) + entry.min;

            class_1799 stack =
                    new class_1799(item, count);

            int slot = randomEmptySlot(barrel);

            if (slot != -1) {
                barrel.method_5447(slot, stack);
            }
        }

        barrel.method_5431();
    }

    private static LootEntry randomEntry(
            List<LootEntry> entries
    ) {

        if (entries.isEmpty()) {
            return null;
        }

        int total = 0;

        for (LootEntry entry : entries) {
            total += entry.weight;
        }

        if (total <= 0) {
            return null;
        }

        int random =
                RANDOM.nextInt(total);

        int current = 0;

        for (LootEntry entry : entries) {

            current += entry.weight;

            if (random < current) {
                return entry;
            }
        }

        return entries.get(0);
    }

    private static int randomEmptySlot(
            class_3719 barrel
    ) {

        List<Integer> empty =
                new ArrayList<>();

        for (int i = 0; i < barrel.method_5439(); i++) {

            if (barrel.method_5438(i).method_7960()) {
                empty.add(i);
            }
        }

        if (empty.isEmpty()) {
            return -1;
        }

        return empty.get(
                RANDOM.nextInt(empty.size())
        );
    }
}