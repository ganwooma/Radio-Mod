package dev.ganwooma.radiomod;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;

import static dev.ganwooma.radiomod.Radiomod.GAUZE;

public class GauzeHealHandler {
    public static void register() {
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {

            // 플레이어만 적용
            if (!(entity instanceof PlayerEntity player)) {
                return true;
            }

            // 공격자가 플레이어인지 확인
            if (!(source.getAttacker() instanceof PlayerEntity attacker)) {
                return true;
            }

            // 공격자가 들고 있는 아이템 확인
            ItemStack stack = attacker.getMainHandStack();

            if (stack.isOf(GAUZE)) {

                // 강한 공격(쿨다운 차징 공격)인지 확인
                if (attacker.getAttackCooldownProgress(0.5f) > 0.9f) {

                    // 힐 (0.1 하트 = 0.2 HP)
                    player.heal(0.2f);

                    // 데미지 취소
                    return false;
                }
            }

            return true;
        });
    }
}
